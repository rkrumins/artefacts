package org.apache.atlas.hive.filter;

import org.apache.atlas.hive.hook.filter.PatternFilterOperation;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PatternFilterOperationTest {

    PatternFilterOperation objectUnderTest;

    List<String> patternList = constructSamplePatternList();
    Set<String> patternSet = constructSamplePatternSet();

    @Test
    public void testCheckIfDatabaseIsOfValidRegexPatternForValidDatabaseNameWithPatternList() {
        objectUnderTest = new PatternFilterOperation(patternList);
        String testDatabaseName1 = "test1";
        String testDatabaseName2 = "my_test";
        String testDatabaseName3 = "test_db_20200101";
        String testDatabaseName4 = "test_db_20200101_test";

        boolean expectedValidFlagValueForDatabaseName1 = true;
        boolean expectedValidFlagValueForDatabaseName2 = false;
        boolean expectedValidFlagValueForDatabaseName3 = true;
        boolean expectedValidFlagValueForDatabaseName4 = false;

        boolean actualValidFlagValueForDatabaseName1 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName1, patternList);
        boolean actualValidFlagValueForDatabaseName2 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName2, patternList);
        boolean actualValidFlagValueForDatabaseName3 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName3, patternList);
        boolean actualValidFlagValueForDatabaseName4 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName4, patternList);

        Assert.assertEquals(actualValidFlagValueForDatabaseName1, expectedValidFlagValueForDatabaseName1);
        Assert.assertEquals(actualValidFlagValueForDatabaseName2, expectedValidFlagValueForDatabaseName2);
        Assert.assertEquals(actualValidFlagValueForDatabaseName3, expectedValidFlagValueForDatabaseName3);
        Assert.assertEquals(actualValidFlagValueForDatabaseName4, expectedValidFlagValueForDatabaseName4);
    }

    @Test
    public void testCheckIfDatabaseIsOfValidRegexPatternForValidDatabaseNameWithPatternSet() {
        objectUnderTest = new PatternFilterOperation(patternSet);
        String testDatabaseName1 = "test1";
        String testDatabaseName2 = "my_test";
        String testDatabaseName3 = "test_db_20200101";
        String testDatabaseName4 = "test_db_20200101_test";

        boolean expectedValidFlagValueForDatabaseName1 = true;
        boolean expectedValidFlagValueForDatabaseName2 = false;
        boolean expectedValidFlagValueForDatabaseName3 = true;
        boolean expectedValidFlagValueForDatabaseName4 = false;

        boolean actualValidFlagValueForDatabaseName1 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName1, patternSet);
        boolean actualValidFlagValueForDatabaseName2 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName2, patternSet);
        boolean actualValidFlagValueForDatabaseName3 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName3, patternSet);
        boolean actualValidFlagValueForDatabaseName4 = objectUnderTest.checkIfDatabaseIsOfValidRegexPattern(testDatabaseName4, patternSet);

        Assert.assertEquals(actualValidFlagValueForDatabaseName1, expectedValidFlagValueForDatabaseName1);
        Assert.assertEquals(actualValidFlagValueForDatabaseName2, expectedValidFlagValueForDatabaseName2);
        Assert.assertEquals(actualValidFlagValueForDatabaseName3, expectedValidFlagValueForDatabaseName3);
        Assert.assertEquals(actualValidFlagValueForDatabaseName4, expectedValidFlagValueForDatabaseName4);
    }

    @Test
    public void testCheckIfValidDatabase() {
        objectUnderTest = new PatternFilterOperation(patternList);
        String testDatabaseName = "test_db_20200101";
        boolean expectedValidFlagValue = true;
        Assert.assertEquals(objectUnderTest.checkIfValidDatabase(testDatabaseName), expectedValidFlagValue);

        objectUnderTest = new PatternFilterOperation(patternSet);
        Assert.assertEquals(objectUnderTest.checkIfValidDatabase(testDatabaseName), expectedValidFlagValue);
    }

    @Test
    public void testCheckIfValidDatabaseWithEmptyPatterns() {
        objectUnderTest = new PatternFilterOperation(new ArrayList<>());
        String testDatabaseName = "test_db_20200101";
        boolean expectedValidFlagValue = false;
        Assert.assertEquals(objectUnderTest.checkIfValidDatabase(testDatabaseName), expectedValidFlagValue);

        objectUnderTest = new PatternFilterOperation(new HashSet<>());
        Assert.assertEquals(objectUnderTest.checkIfValidDatabase(testDatabaseName), expectedValidFlagValue);
    }

    private List<String> constructSamplePatternList() {
        List<String> samplePatternList = new ArrayList<>();
        samplePatternList.add("test1|test2");
        samplePatternList.add("([a-z]+)_([a-z]+)_(\\d+)");
        samplePatternList.add("([a-z]+)_(\\d+)");
        return samplePatternList;
    }

    private Set<String> constructSamplePatternSet() {
        List<String> samplePatternList = constructSamplePatternList();
        return new HashSet<>(samplePatternList);
    }
}
