package org.apache.atlas.hive.filter;

import org.apache.atlas.hive.hook.filter.FilterUtils;
import org.apache.atlas.hive.hook.filter.constants.FilterConstants;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FilterUtilsTest {

    @Test
    public void testConstructValidPath() {
        String expectedFullPath = "/user/data/file.txt";

        String testBasePath = "/user/data";
        String testFileName = "file.txt";

        String actualFullPath = FilterUtils.constructValidPath(testBasePath, testFileName);
        Assert.assertEquals(actualFullPath, expectedFullPath);
    }

    @Test
    public void testConstructValidPathWithBasePathTrailingSlash() {
        String expectedFullPath = "/user/data/file.txt";

        String testBasePath = "/user/data/";
        String testFileName = "file.txt";

        String actualFullPath = FilterUtils.constructValidPath(testBasePath, testFileName);
        Assert.assertEquals(actualFullPath, expectedFullPath);
    }

    @Test
    public void testConstructValidPathWithFileNameLeadingSlash() {
        String expectedFullPath = "/user/data/file.txt";

        String testBasePath = "/user/data";
        String testFileName = "./file.txt";

        String actualFullPath = FilterUtils.constructValidPath(testBasePath, testFileName);
        Assert.assertEquals(actualFullPath, expectedFullPath);
    }

    @Test
    public void testTrimWhitespacesAndRemoveEmptyItemsInListWithEmptyElementInput() {
        List<String> sampleTestList = constructSampleTestList();
        int expectedTestListSize = sampleTestList.size();

        sampleTestList.add("");
        sampleTestList.add("");

        List<String> actualTestList = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(sampleTestList);

        Assert.assertEquals(actualTestList.size(), expectedTestListSize);
    }

    @Test
    public void testTrimWhitespacesAndRemoveEmptyItemsInListWithLeadingSpaces() {
        List<String> sampleTestList = new ArrayList<>();

        sampleTestList.add("   (test1|test2)");
        sampleTestList.add("   \\w+");

        List<String> actualTestList = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(sampleTestList);

        String expectedFormattedResult1 = "(test1|test2)";
        String expectedFormattedResult2 = "\\w+";

        Assert.assertEquals(actualTestList.size(), sampleTestList.size());
        Assert.assertEquals(actualTestList.get(0), expectedFormattedResult1);
        Assert.assertEquals(actualTestList.get(1), expectedFormattedResult2);
    }


    @Test
    public void testTrimWhitespacesAndRemoveEmptyItemsInListWithTrailingSpaces() {
        List<String> sampleTestList = new ArrayList<>();

        sampleTestList.add("(test1|test2)     ");
        sampleTestList.add("\\w+    ");

        String expectedFormattedResult1 = "(test1|test2)";
        String expectedFormattedResult2 = "\\w+";

        int expectedTestListSize = 2;
        List<String> actualTestList = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(sampleTestList);

        Assert.assertEquals(actualTestList.size(), expectedTestListSize);
        Assert.assertEquals(actualTestList.get(0), expectedFormattedResult1);
        Assert.assertEquals(actualTestList.get(1), expectedFormattedResult2);
    }

    @Test
    public void testTrimWhitespacesAndRemoveEmptyItemsInListWithLeadingAndTrailingSpacesAndEmptyElements() {
        List<String> sampleTestList = new ArrayList<>();

        String expectedFormattedResult1 = "(test1|test2)";
        String expectedFormattedResult2 = "\\w+";

        sampleTestList.add("    (test1|test2)     ");
        sampleTestList.add("    \\w+    ");
        sampleTestList.add("");
        sampleTestList.add("     ");
        sampleTestList.add(null);

        int expectedTestListSize = 2;
        List<String> actualTestList = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(sampleTestList);

        Assert.assertEquals(actualTestList.size(), expectedTestListSize);
        Assert.assertEquals(actualTestList.get(0), expectedFormattedResult1);
        Assert.assertEquals(actualTestList.get(1), expectedFormattedResult2);
    }

    @Test
    public void testTrimWhitespacesAndRemoveEmptyItemsInListWithNullItemsLoaded() {
        List<String> sampleTestList = constructSampleTestList();
        int expectedTestListSize = sampleTestList.size();

        sampleTestList.add(null);
        sampleTestList.add(null);

        List<String> actualTestList = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(sampleTestList);

        Assert.assertEquals(actualTestList.size(), expectedTestListSize);
    }

    @Test
    public void testGetDatabaseNameFromColumnQualifiedName() {
        String expectedDatabaseName = "test_db";
        String testQualifiedName = "test_db.test_table.test_column@CLUSTER";

        String actualDatabaseName = FilterUtils.getDatabaseNameFromQualifiedName(testQualifiedName);
        Assert.assertEquals(actualDatabaseName, expectedDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromTableQualifiedName() {
        String expectedDatabaseName = "test_db";
        String testQualifiedName = "test_db.test_table@CLUSTER";

        String actualDatabaseName = FilterUtils.getDatabaseNameFromQualifiedName(testQualifiedName);
        Assert.assertEquals(actualDatabaseName, expectedDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromDatabaseQualifiedName() {
        String expectedDatabaseName = "test_db";
        String testQualifiedName = "test_db@CLUSTER";

        String actualDatabaseName = FilterUtils.getDatabaseNameFromQualifiedName(testQualifiedName);
        Assert.assertEquals(actualDatabaseName, expectedDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithCreateTableAsSelect() {
        String expectedSourceDatabaseName = "test_db";
        String expectedTargetDatabaseName = "test_db";
        String testQueryQualifiedName = "QUERY:test_db.source_test_table_name_20200101_111111_stg@test_cluster:16665050->:INSERT:test_db.target_test_table_name_20200101_111111_stg@test_cluster:16665050";

        List<String> actualDatabaseNamesList = FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName);
        String actualSourceDatabaseName = actualDatabaseNamesList.get(0);
        String actualTargetDatabaseName = actualDatabaseNamesList.get(1);

        Assert.assertEquals(2, actualDatabaseNamesList.size());
        Assert.assertEquals(actualSourceDatabaseName, expectedSourceDatabaseName);
        Assert.assertEquals(actualTargetDatabaseName, expectedTargetDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithInsertValuesQuery() {
        String expectedSourceDatabaseName = "default";
        String expectedTargetDatabaseName = "test_db";
        String testQueryQualifiedName = "QUERY:default.values__tmp_table__1_temp-hash-code@test_cluster:16665050->:INSERT:test_db.test_table_name@test_cluster:16665050";

        List<String> actualDatabaseNamesList = FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName);
        String actualSourceDatabaseName = actualDatabaseNamesList.get(0);
        String actualTargetDatabaseName = actualDatabaseNamesList.get(1);

        Assert.assertEquals(2, actualDatabaseNamesList.size());
        Assert.assertEquals(actualSourceDatabaseName, expectedSourceDatabaseName);
        Assert.assertEquals(actualTargetDatabaseName, expectedTargetDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithDeleteTableWhereConditionQuerySubQuery() {
        String expectedSourceDatabaseName1 = "test_db";
        String expectedSourceDatabaseName2 = "test_db";
        String expectedTargetDatabaseName = "test_db";
        String testQueryQualifiedName = "QUERY:test_db.source_test_table_name@test_cluster:16665050:test_db.source_test_table_name2@test_cluster:16665050->:DELETE:test_db.test_table_name@test_cluster:16665050";

        List<String> actualDatabaseNamesList = FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName);
        String actualSourceDatabaseName1 = actualDatabaseNamesList.get(0);
        String actualSourceDatabaseName2 = actualDatabaseNamesList.get(1);
        String actualTargetDatabaseName = actualDatabaseNamesList.get(2);

        Assert.assertEquals(3, actualDatabaseNamesList.size());
        Assert.assertEquals(actualSourceDatabaseName1, expectedSourceDatabaseName1);
        Assert.assertEquals(actualSourceDatabaseName2, expectedSourceDatabaseName2);
        Assert.assertEquals(actualTargetDatabaseName, expectedTargetDatabaseName);
    }

    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithDeleteTableWhereConditionQuerySubQueryWithDifferentInputDatabases() {
        String expectedInputDatabaseName1 = "test_db1";
        String expectedInputDatabaseName2 = "test_db2";
        String expectedInputDatabaseName3 = "test_db3";
        String expectedTargetDatabaseName = "test_db";

        Set<String> expectedDatabaseSet = new HashSet();
        expectedDatabaseSet.add(expectedInputDatabaseName1);
        expectedDatabaseSet.add(expectedInputDatabaseName2);
        expectedDatabaseSet.add(expectedInputDatabaseName3);
        expectedDatabaseSet.add(expectedTargetDatabaseName);

        String testQueryQualifiedName = "QUERY:test_db1.source_test_table_name@test_cluster:16665050:test_db2.source_test_table_name2@test_cluster:16065050:test_db3.source_test_table_name2@test_cluster:18665050->:DELETE:test_db.test_table_name@test_cluster:16665050";

        Set<String> actualDatabaseNamesList = new HashSet<>(FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName));

        Assert.assertEquals(4, actualDatabaseNamesList.size());
        for (String actualDatabaseName: actualDatabaseNamesList) {
            Assert.assertTrue(actualDatabaseNamesList.contains(actualDatabaseName));
        }
        Assert.assertEquals(actualDatabaseNamesList, expectedDatabaseSet);
    }

    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithDeleteTableWhereConditionQuery() {
        String expectedSourceDatabaseName = "test_db";
        String testQueryQualifiedName = "QUERY:test_db.source_test_table_name@test_cluster:16665050";

        List<String> actualDatabaseNamesList = FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName);
        String actualSourceDatabaseName = actualDatabaseNamesList.get(0);

        Assert.assertEquals(1, actualDatabaseNamesList.size());
        Assert.assertEquals(actualSourceDatabaseName, expectedSourceDatabaseName);
    }


    @Test
    public void testGetDatabaseNameFromFullQueryQualifiedNameWithUpdateOperation() {
        String expectedSourceDatabaseName = "test_db";
        String expectedPostOperationDatabaseName = "test_db";
        String testQueryQualifiedName = "QUERY:test_db.source_test_table_name@test_cluster:16665050->:UPDATE:test_db.source_test_table_name@test_cluster:16665050";

        List<String> actualDatabaseNamesList = FilterUtils.getDatabaseNamesFromQueryQualifiedName(testQueryQualifiedName);
        String actualSourceDatabaseName = actualDatabaseNamesList.get(0);
        String actualPostOperationDatabaseName = actualDatabaseNamesList.get(1);

        Assert.assertEquals(2, actualDatabaseNamesList.size());
        Assert.assertEquals(actualSourceDatabaseName, expectedSourceDatabaseName);
        Assert.assertEquals(actualPostOperationDatabaseName, expectedPostOperationDatabaseName);
    }

    private List<String> constructSampleTestList() {
        List<String> sampleList = new ArrayList<>();
        sampleList.add("([A-Z])\\w+");
        sampleList.add("(\\w+)");
        sampleList.add("(abc|cde)");
        return sampleList;
    }

    private List<String> constructSampleQueryTextList() {
        List<String> sampleQueryTextList = new ArrayList<>();
        return sampleQueryTextList;
    }

}
