package org.apache.atlas.hive.utils;

import org.apache.atlas.hive.hook.filter.constants.FilterConstants;
import org.apache.atlas.hive.hook.utils.MaskUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MaskUtilsTest {

    @Test
    public void testGetMaskedQueryTextFromInsertQueryWithValues() {
        String testQuery = "insert into test_db.test_table values (test123)";
        String expectedMaskedQuery = String.format("insert into test_db.test_table values (%s)", FilterConstants.MASK_DEFAULT_VALUE);
        String actualMaskedQuery = MaskUtils.maskSensitiveDataFromInsertValuesQuery(testQuery);
        Assert.assertEquals(actualMaskedQuery, expectedMaskedQuery);
    }

    @Test
    public void testGetMaskedQueryTextFromInsertQuery() {
        String testQuery = "insert into test_db.test_table as select * from test_db2.test_table2";
        String actualMaskedQuery = MaskUtils.maskSensitiveDataFromInsertValuesQuery(testQuery);
        Assert.assertEquals(actualMaskedQuery, testQuery);
    }

}
