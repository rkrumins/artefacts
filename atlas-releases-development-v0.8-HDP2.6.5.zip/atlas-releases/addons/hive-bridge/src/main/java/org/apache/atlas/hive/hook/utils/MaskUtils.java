package org.apache.atlas.hive.hook.utils;

import org.apache.atlas.hive.hook.filter.FilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.atlas.hive.hook.filter.constants.FilterConstants.INSERT_QUERY_REGEX_PATTERN;
import static org.apache.atlas.hive.hook.filter.constants.FilterConstants.MASK_DEFAULT_VALUE;

public class MaskUtils {

    private static final Logger LOG = LoggerFactory.getLogger(MaskUtils.class);

    public static String maskSensitiveDataFromInsertValuesQuery(String queryText) {
        Pattern pattern = Pattern.compile(INSERT_QUERY_REGEX_PATTERN);
        Matcher matcher = pattern.matcher(queryText.toLowerCase());

        if (matcher.find()) {
            if (matcher.groupCount() > 0) {
                // Retrieve only contents inside values group as only single group should be defined in regex expression
                // as per default group(0) captures entire expression and group(1) captures data to be masked
                String sensitiveContents = matcher.group(1);
                if (!sensitiveContents.isEmpty()) {
                    LOG.debug("MaskUtils: Masking insert values contents in query text");
                    return queryText.replace(sensitiveContents, MASK_DEFAULT_VALUE);
                }
            } else {
                // Log exception when no group is specified in regex expression
                LOG.error("MaskUtils: No group specified in regex expression: {} for masking values in insert values query", INSERT_QUERY_REGEX_PATTERN);
                LOG.error("MaskUtils Was not able to perform masking for queryText, therefore storing as it is");
            }
        }

        return queryText;
    }
}
