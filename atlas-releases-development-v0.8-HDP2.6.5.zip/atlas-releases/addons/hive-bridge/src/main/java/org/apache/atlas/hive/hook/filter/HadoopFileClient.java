/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.atlas.hive.hook.filter;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;

/**
 * This is Hadoop File System Client for reading source entities list from Hadoop Distributed File System (HDFS)
 */
public class HadoopFileClient implements FilterFileClient {
    public String filterFileBasePath;
    public String filterFileName;

    private static final Logger LOG = LoggerFactory.getLogger(HadoopFileClient.class);

    private static final String HADOOP_CONF_DIR = System.getenv("HADOOP_CONF_DIR");

    public HadoopFileClient(String filterFileBasePath, String filterFileName) {
        this.filterFileBasePath = filterFileBasePath;
        this.filterFileName = filterFileName;
    }

    @Override
    public List<String> getValidSources() {
        LOG.debug("HADOOP_CONF_DIR value is set to " + HADOOP_CONF_DIR);

        // Initialise Hadoop Configuration
        Configuration conf = new Configuration();

        LOG.debug("Printing configuration for Hadoop");
        LOG.debug(conf.toString());

        List<String> validEntitiesListFromFile = null;

        Path hdfsFilterFileFullPath = FilterUtils.getFullHdfsPath(filterFileBasePath, filterFileName);

        try (
                FileSystem fs = FileSystem.get(conf);
                FSDataInputStream inputStream = fs.open(hdfsFilterFileFullPath)
        ) {
            LOG.debug("Reading file from hdfs");
            LOG.info("Full path on HDFS set to for Atlas Hive Hook filter file {}", hdfsFilterFileFullPath.toString());

            validEntitiesListFromFile = IOUtils.readLines(inputStream, StandardCharsets.UTF_8);

            LOG.info("Loaded filter file for Atlas Hive Hook from HDFS with {} items in valid entities list", validEntitiesListFromFile.size());

        } catch (IOException e) {
            LOG.error("IOException occurred whilst loading filter file from HDFS");
            LOG.error("Failed to load file from HDFS at this path {}/{}", filterFileBasePath, filterFileName);
        }

        if (validEntitiesListFromFile != null) {
            List<String> validEntityListPostCleanup = FilterUtils.trimWhitespacesAndRemoveEmptyItemsInList(validEntitiesListFromFile);
            LOG.info("Post clean-up filter file for Atlas Hive Hook contains {} items in valid entities list", validEntitiesListFromFile.size());
            LOG.debug("Valid entities list size " + validEntitiesListFromFile.size());
            LOG.debug("Valid entities list contents below: ");
            LOG.debug(Arrays.toString(validEntitiesListFromFile.toArray()));
            // To do: Add explicit check for when this is returned as null
            return validEntityListPostCleanup;
        } else {
            LOG.error("List is empty for valid entities");
            LOG.error("Could not construct list of valid entities");
        }

        // List returned is empty
        LOG.error("No contents were loaded from {} file on HDFS", hdfsFilterFileFullPath.toString());
        return validEntitiesListFromFile;

    }
}
