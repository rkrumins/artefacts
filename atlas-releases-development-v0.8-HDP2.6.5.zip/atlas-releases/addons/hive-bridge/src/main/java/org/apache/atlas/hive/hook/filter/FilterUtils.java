/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.atlas.hive.hook.filter;

import org.apache.atlas.model.instance.AtlasEntity;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static org.apache.atlas.hive.hook.events.BaseHiveEvent.ATTRIBUTE_QUALIFIED_NAME;
import static org.apache.atlas.hive.hook.filter.constants.FilterConstants.*;

/**
 * This class is for the utils used by filtering feature
 **/
public final class FilterUtils {

    private static final Logger LOG = LoggerFactory.getLogger(FilterUtils.class);

    public static Set<String> getValidEntitySetFromList(List<String> validEntitiesList) {
        if (validEntitiesList == null || validEntitiesList.isEmpty()) {
            LOG.error("Empty list passed, therefore unable to generate set from an existing list of items");
            return new HashSet<>();
        }
        return new HashSet<>(validEntitiesList);
    }

    public static String constructValidPath(String basePath, String fileName) {
        String fullFilterFilePathString = FilenameUtils.concat(basePath, fileName);
        LOG.debug("Full path constructed {}", fullFilterFilePathString);
        return fullFilterFilePathString;
    }

    public static List<String> trimWhitespacesAndRemoveEmptyItemsInList(List<String> list) {
        // Remove any leading or following whitespace characters
        ListIterator<String> iterator = list.listIterator();

        while (iterator.hasNext()) {
            String s = iterator.next();
            if (s == null || s.isEmpty() || s.trim().length() < 1) {
                iterator.remove();
            } else {
                iterator.set(s.trim());
            }
        }

        return list;
    }

    public static Path getFullHdfsPath(String basePath, String fileName) {
        String fullPathString = FilterUtils.constructValidPath(basePath, fileName);
        return new Path(fullPathString);
    }

    public static String getDatabaseNameFromQualifiedName(String qualifiedName) {
        // Gets database name from qualifiedName which is of format: $HIVE_DB.$HIVE_TABLE.$HIVE_COLUMN@$CLUSTER
        // e.g. test_database.test_table.test_column@TEST_CLUSTER for column
        // e.g. test_database.test_table@TEST_CLUSTER for table
        // e.g. test_database@TEST_CLUSTER for database

        String QUALIFIED_NAME_ENTITY_SEPARATOR = ".";
        String QUALIFIED_NAME_CLUSTER_SEPARATOR = "@";

        String entityName = StringUtils.substringBefore(qualifiedName, QUALIFIED_NAME_CLUSTER_SEPARATOR);
        String databaseName = StringUtils.substringBefore(entityName, QUALIFIED_NAME_ENTITY_SEPARATOR);

        if (databaseName.isEmpty()) {
            // QualifiedName for database passed, hence why databaseName is returned empty after substring extraction
            // Entity name reflects the actual name of database in this case
            return entityName;
        }
        return databaseName;
    }

    public static List<String> getDatabaseNamesFromQueryQualifiedName(String queryQualifiedName) {
        // Gets database name from qualifiedName of type QUERY which is of format: $HIVE_DB.$HIVE_TABLE.$HIVE_COLUMN@$CLUSTER
        // e.g. QUERY:$TEST_DB_NAME.$TEST_TABLE_NAME_$LONG_TIMESTAMP.$TEST_DB_NAME_tmp@$CLUSTER:$TIMESTAMP->:$OPERATION:$TEST_DB_NAME.$TEST_TABLE_NAME_$LONG_TIMESTAMP_stg@$CLUSTER:$TIMESTAMP
        // e.g. QUERY:test_db.source_test_table_name_20200101_111111_tmp@test_cluster:166650500->:INSERT:test_db.target_table@test_cluster:198650500


        String sourceQualifiedNames = StringUtils.substringBetween(queryQualifiedName, QUALIFIED_NAME_QUERY_INPUTS_ENTITY_KEYWORD, QUALIFIED_NAME_INPUTS_OUTPUTS_SEPARATOR);
        if (sourceQualifiedNames == null) {
            LOG.debug("Query qualifiedName is does not contain any outputs, extracting inputsQualifiedName from inputs only");
            sourceQualifiedNames = StringUtils.substringAfter(queryQualifiedName, QUALIFIED_NAME_QUERY_INPUTS_ENTITY_KEYWORD);
        }

        String inputsQualifiedNames = sourceQualifiedNames;

        List<String> databaseNamesList = new ArrayList<>();

        // Capture all all entity qualifiedNames in inputs
        String[] sourceInputs = StringUtils.split(inputsQualifiedNames, QUALIFIED_SOURCE_NAME_ENTITY_SEPARATOR);

        if (sourceInputs == null) {
            // This refers to the case where only one input was specified in qualifiedName for query
            String databaseName = StringUtils.substringBefore(inputsQualifiedNames, QUALIFIED_NAME_ENTITY_SEPARATOR);
            databaseNamesList.add(databaseName);
            LOG.debug("Added database {} to database names list from input qualifiedNames", databaseName);
        } else {
            Set<String> sourceInputsList = new HashSet<>(Arrays.asList(sourceInputs));
            LOG.debug("More than one source input is present, thus extracting database names from input qualifiedNames");
            sourceInputsList.forEach(x -> {
                if (StringUtils.contains(x, QUALIFIED_NAME_CLUSTER_SEPARATOR)) {
                    // Ensure only entity qualifiedNames with cluster name specified  are added to list
                    // (as defined per Atlas qualifiedNames standards)
                    String databaseName = StringUtils.substringBefore(x, QUALIFIED_NAME_ENTITY_SEPARATOR);
                    databaseNamesList.add(databaseName);
                }
            });
            LOG.debug("Added total of {} unique database names to database names list from inputs", databaseNamesList.size());
            LOG.debug("Databases {} added from inputs", databaseNamesList);
        }

        String targetOperationFullQualifiedName = StringUtils.substringAfter(queryQualifiedName, QUALIFIED_NAME_INPUTS_OUTPUTS_SEPARATOR);
        String targetDatabaseNameFromQueryOperation = StringUtils.substringBetween(targetOperationFullQualifiedName, QUALIFIED_OPERATION_NAME_ENTITY_SEPARATOR, QUALIFIED_NAME_ENTITY_SEPARATOR);

        if (targetDatabaseNameFromQueryOperation != null) {
            databaseNamesList.add(targetDatabaseNameFromQueryOperation);
            LOG.debug("Added database to databases name list from outputs qualifiedNames");
        } else {
            LOG.debug("No outputs are present, thus no database name is added");
        }

        LOG.debug("Database names list constructed from query qualifiedName: {}", databaseNamesList);
        return databaseNamesList;
    }

    public static Set<String> getDatabaseNamesFromQualifiedName(List<AtlasEntity> atlasEntitiesList) {
        Set<String> databaseNamesSet = new HashSet<>();

        if (atlasEntitiesList != null){
            if (!atlasEntitiesList.isEmpty()) {
                for (AtlasEntity atlasEntity: atlasEntitiesList) {
                    Object qualifiedName = atlasEntity.getAttribute(ATTRIBUTE_QUALIFIED_NAME);
                    String databaseName = FilterUtils.getDatabaseNameFromQualifiedName(qualifiedName.toString());
                    LOG.debug("FilterUtils: for qualifiedName: {} database name extracted: {}", qualifiedName.toString(), databaseName);
                    databaseNamesSet.add(databaseName);
                }
            }
        }

        return databaseNamesSet;
    }

    public static List<String> getDatabaseNamesFromInputsOutputsAttribute(List<AtlasEntity> inputs, List<AtlasEntity> outputs) {
        Set<String> databaseNamesSet = new HashSet<>();

        Set<String> inputsDatabaseNamesSet = getDatabaseNamesFromQualifiedName(inputs);
        Set<String> outputsDatabaseNamesSet = getDatabaseNamesFromQualifiedName(outputs);

        databaseNamesSet.addAll(inputsDatabaseNamesSet);
        databaseNamesSet.addAll(outputsDatabaseNamesSet);

        LOG.debug("Total of {} databases obtained from inputs and outputs", databaseNamesSet.size());

        return new ArrayList<>(databaseNamesSet);
    }

}
