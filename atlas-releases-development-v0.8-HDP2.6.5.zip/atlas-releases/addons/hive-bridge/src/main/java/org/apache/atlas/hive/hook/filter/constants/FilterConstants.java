package org.apache.atlas.hive.hook.filter.constants;

public class FilterConstants {

    // Default hook ingest entities policy: refers to use-case when no filter file is specified or not found
    // If set to true, this will allow all entity metadata to be loaded in Atlas from Hive Hook, meaning no filtering is taking place
    // If set to false, this will prevent from any entity metadata to be loaded in Atlas from Hive Hook
    public static final boolean HOOK_INGEST_ALL_DEFAULT_POLICY_VALUE = true;
    public static final String HOOK_INGEST_ALL_REGEX_PATTERN = ".*";

    // Filter file constants
    public static final String HOOK_FILTER_FILE_DEFAULT_FILESYSTEM = "hdfs";

    // Masking constants
    // For Regex pattern in queries, ensure only single group is defined in regex
    public static final String INSERT_QUERY_REGEX_PATTERN = "values\\s*\\((.*)\\)";
    public static final String MASK_DEFAULT_VALUE = "***MASKED VALUES***";

    // Constants for operations on qualifiedName attribute
    public final static String QUALIFIED_NAME_ENTITY_SEPARATOR = ".";
    public final static String QUALIFIED_NAME_INPUTS_OUTPUTS_SEPARATOR = "->:";
    public final static String QUALIFIED_NAME_QUERY_INPUTS_ENTITY_KEYWORD = "QUERY:";
    public final static String QUALIFIED_SOURCE_NAME_ENTITY_SEPARATOR = ":";
    public final static String QUALIFIED_NAME_CLUSTER_SEPARATOR = "@";
    public final static String QUALIFIED_OPERATION_NAME_ENTITY_SEPARATOR = ":";

}
