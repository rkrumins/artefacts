package org.apache.atlas.hive.hook.filter;

public class FilterOperationContext {
    private final FilterStrategy filterStrategy;

    public FilterOperationContext(FilterStrategy filterStrategy){
        this.filterStrategy = filterStrategy;
    }

    public boolean evaluateStrategy(String databaseName){
        return filterStrategy.evaluate(databaseName);
    }
}
