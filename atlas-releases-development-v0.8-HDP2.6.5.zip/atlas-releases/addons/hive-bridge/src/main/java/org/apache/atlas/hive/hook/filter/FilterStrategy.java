package org.apache.atlas.hive.hook.filter;

public interface FilterStrategy {
    boolean evaluate(String databaseName);
}
